It's modified node for krea2edit with 5 images references. Also I put modified workflow to work with 5 image references

don't forget downloading **[krea 2 identity lora](https://civitai.red/models/2761113/krea-2-identity-edit?modelVersionId=3139172)** for correct edit working
